read -p "Please enter a directory to zip: " directory
output="/home/VISSMJ1/Assignment-1/OSC-Assignment/OSC-Assignment1/Task_2/backup-$(date +%Y-%m-%d).tgz"
# Compresses the outputed directory
tar -czvf "$output" -C "$directory" .
ls -lh "$output"
# List archive contents (no extraction)
tar -tzvf "$output"
# Count how many files arein the archive
tar -tzvf "$output" | wc -l
#Check for any obvious problems (e.g. absolute paths starting with /)
tar -tzvf "$output" | grep "^/" | head -5
