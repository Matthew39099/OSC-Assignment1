read -p "Please enter a directory to zip " directory
tar -czvf /home/VISSMJ1/Assignment-1/OSC-Assignment/OSC-Assignment1/Task_2/backup.tgz -C /$directory .
ls -lh /home/VISSMJ1/Assignment-1/OSC-Assignment/OSC-Assignment1/Task_2/backup.tgz
#List archive contents (no extraction)
tar -tzvf /home/VISSMJ1/Assignment-1/OSC-Assignment/OSC-Assignment1/Task_2/backup.tgz
# Count how many files arein the archive
tar -tzvf /home/VISSMJ1/Assignment-1/OSC-Assignment/OSC-Assignment1/Task_2/backup.tgz | wc -l
# Check for any obvious problems (e.g. absolute paths starting with /)
tar -tzvf /home/VISSMJ1/Assignment-1/OSC-Assignment/OSC-Assignment1/Task_2/backup.tgz | grep "^/" | head -5

